hold on 
plot3(Ximu(:,2),Ximu(:,3),Ximu(:,4))
hold off