function probability_1gaussian_prior()
%Test encoding and decoding of simple, monomodal, gaussian probability distributions when network weights are modified so as to include a prior
inputs=[-180:10:179];
centres=[-180:22.5:179];
priorMean=0;
priorStd=60;

%define weights, to produce a 1d basis function network, where nodes have gaussian RFs. Strength of RFs is modulated by prior distribution. 
W=[];
for c=centres
  W=[W;code(c,inputs,15).*prior(inputs,priorMean,priorStd)];
end
[n,m]=size(W);

%define test cases
X=zeros(m,3);
X(:,1)=code(105,inputs,20)'; 
X(:,2)=code(105,inputs,30)'; 
X(:,3)=code(-30,inputs,20)';
X(:,4)=code(-30,inputs,40)';

for k=1:size(X,2)
  x=X(:,k);
  [y,e,r]=dim_activation(W,x);
  figure(k),clf
  plot_result(x,r,y,inputs,centres);
  plot(5.*x'.*prior(inputs,priorMean,priorStd),'LineWidth',2)
  print(gcf, '-dpdf', ['probability_1gaussian_prior',int2str(k),'.pdf']); 
end

%calculate performance averaged over many trials
trials=1e6
decode_compare=zeros(trials,3);
for k=1:trials
  if rem(k,1000)==0; fprintf(1,'.%i.',k); end
  likelihoodMean=240*rand-120; %avoid bimodal posterior distributions!
  likelihoodStd=20+30*rand;
  x=code(likelihoodMean,inputs,likelihoodStd,1)'; %noisy PPC
  [y,e,r]=dim_activation(W,x);
  
  posteriorMean=stats_gaussian_product(likelihoodMean,likelihoodStd,priorMean,priorStd);
  decode_compare(k,:)=[posteriorMean,decode(r',inputs),decode(y',centres)];
end
disp(' ');
stdR=sqrt(est_var(decode_compare(:,1)',decode_compare(:,2)')) %compare mean of posterior estimated from reconstruction to true mean




function p=prior(x,Mean,Std)
p=0.25.*exp(-(0.5/Std^2).*(x-Mean).^2);



function c=code(x,X,sigma,noise)
c=zeros(1,length(X),'single');
c=19.*exp(-(0.5/sigma.^2).*min([abs(x-X);abs(x-(X+360));abs(x-(X-360))]).^2)./sigma;
if nargin>3 && noise
  c=single(imnoise(uint8(125.*c),'poisson'))./125; %add poisson noise
end



function x=decode(c,inputs)
x=angle(sum(c.*exp(i.*inputs.*pi/180))).*180/pi;
if sum(c)==0, x=NaN; end



function var=est_var(true,est)
M=length(true);
var=sum(min([abs(est-true);abs(est-(true+360));abs(est-(true-360))]).^2)/(M-1);



function plot_result(x,r,y,inputs,centres)
top=1.05;
axes('Position',[0.12,0.05,0.76,0.24]),
bar(x,1,'k'),axis([0.5,length(x)+0.5,0,top])
set(gca,'XTick',[1:9:length(x)],'XTickLabel',inputs(1:9:length(x)),'FontSize',18);
plot_decode(x,inputs);
text(0.01,1,'x','Units','normalized','color','k','FontSize',18,'FontWeight','bold','VerticalAlignment','top')

axes('Position',[0.12,0.38,0.76,0.24]),
bar(y,1,'r'),axis([0.5,length(y)+0.5,0,top])
set(gca,'XTick',[1:2:length(y)],'XTickLabel',[1:2:length(y)],'FontSize',18);
text(0.01,1,'y','Units','normalized','color','r','FontSize',18,'FontWeight','bold','VerticalAlignment','top')

axes('Position',[0.12,0.71,0.76,0.24]),
bar(r,1,'FaceColor',[0,0.7,0]),axis([0.5,length(x)+0.5,0,top])
set(gca,'XTick',[1:9:length(x)],'XTickLabel',inputs(1:9:length(x)),'FontSize',18);
plot_decode(r,inputs);
text(0.01,1,'r','Units','normalized','color',[0,0.7,0],'FontSize',18,'FontWeight','bold','VerticalAlignment','top')

set(gcf,'PaperSize',[18 16],'PaperPosition',[0 0.5 18 15],'PaperOrientation','Portrait');



function plot_decode(x,inputs)
hold on, 
ml=decode(x',inputs);
mlconv=1+((ml-min(inputs)).*(length(inputs)-1)./(max(inputs)-min(inputs)));
plot(mlconv.*[1,1],[0,2],'w--','LineWidth',2),
plot(mlconv.*[1,1],[0,2],'k--'),
ax=axis;
text('Position',[mlconv,ax(4)*0.98],'String',num2str(round(ml.*10)/10),'HorizontalAlignment','center','VerticalAlignment','Bottom','FontSize',18,'FontWeight','bold');
