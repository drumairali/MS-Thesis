function probability_1gaussian()
%Test encoding and decoding of simple, monomodal, gaussian probability distributions
inputs=[-180:10:179];
centres=[-180:22.5:179];

%define weights, to produce a 1d basis function network, where nodes have gaussian RFs.
W=[];
for c=centres
  W=[W;code(c,inputs,15)];
end

%normalise weights
W=bsxfun(@rdivide,W,max(1e-6,sum(W,2)));
[n,m]=size(W);

%define test cases
X=zeros(m,3);
X(:,1)=code(105,inputs,20,1)'; %noisy
X(:,2)=code(105,inputs,30,1)'; %noisy
X(:,3)=code(105,inputs,20)'; %no noise

for k=1:size(X,2)
  x=X(:,k);
  [y,e,r]=dim_activation(W,x);
  figure(k),clf
  plot_result(x,r,y,inputs,centres);
  print(gcf, '-dpdf', ['probability_1gaussian',int2str(k),'.pdf']);
end

%calculate performance averaged over many trials
trials=1e6
decode_compare=zeros(trials,3);
for k=1:trials
  if rem(k,1000)==0; fprintf(1,'.%i.',k); end
  trueMean=360*rand-180;
  trueStd=20;
  x=code(trueMean,inputs,trueStd,1)'; %noisy PPC
  [y,e,r]=dim_activation(W,x);
  decode_compare(k,:)=[trueMean,decode(x',inputs),decode(r',inputs)];
end
disp(' ');
varML=est_var(decode_compare(:,1)',decode_compare(:,2)') %compare mean of distribution estimated from input pattern to true mean
varR=est_var(decode_compare(:,1)',decode_compare(:,3)') %compare mean of distribution estimated from reconstruction to true mean
100.*(varR-varML)./varML



function c=code(x,X,sigma,noise)
c=zeros(1,length(X),'single');
c=19.*exp(-(0.5/sigma.^2).*min([abs(x-X);abs(x-(X+360));abs(x-(X-360))]).^2)./sigma;
if nargin>3 && noise
  c=single(imnoise(uint8(125.*c),'poisson'))./125; %add poisson noise
end



function x=decode(c,inputs)
x=angle(sum(c.*exp(i.*inputs.*pi/180))).*180/pi;
if sum(c)==0, x=NaN; end



function var=est_var(true,est)
M=length(true);
var=sum(min([abs(est-true);abs(est-(true+360));abs(est-(true-360))]).^2)/(M-1);



function plot_result(x,r,y,inputs,centres)
top=1.05;
axes('Position',[0.12,0.05,0.76,0.24]),
bar(x,1,'k'),axis([0.5,length(x)+0.5,0,top])
set(gca,'XTick',[1:9:length(x)],'XTickLabel',inputs(1:9:length(x)),'FontSize',18);
plot_decode(x,inputs);
text(0.01,1,'x','Units','normalized','color','k','FontSize',18,'FontWeight','bold','VerticalAlignment','top')

axes('Position',[0.12,0.38,0.76,0.24]),
bar(y,1,'r'),axis([0.5,length(y)+0.5,0,top])
set(gca,'XTick',[1:2:length(y)],'XTickLabel',[1:2:length(y)],'FontSize',18);
text(0.01,1,'y','Units','normalized','color','r','FontSize',18,'FontWeight','bold','VerticalAlignment','top')

axes('Position',[0.12,0.71,0.76,0.24]),
bar(r,1,'FaceColor',[0,0.7,0]),axis([0.5,length(x)+0.5,0,top])
set(gca,'XTick',[1:9:length(x)],'XTickLabel',inputs(1:9:length(x)),'FontSize',18);
plot_decode(r,inputs);
text(0.01,1,'r','Units','normalized','color',[0,0.7,0],'FontSize',18,'FontWeight','bold','VerticalAlignment','top')

set(gcf,'PaperSize',[18 16],'PaperPosition',[0 0.5 18 15],'PaperOrientation','Portrait');



function plot_decode(x,inputs)
hold on, 
ml=decode(x',inputs);
mlconv=1+((ml-min(inputs)).*(length(inputs)-1)./(max(inputs)-min(inputs)));
plot(mlconv.*[1,1],[0,100],'w--','LineWidth',2),
plot(mlconv.*[1,1],[0,100],'k--'),
ax=axis;
text('Position',[mlconv,ax(4)*0.98],'String',num2str(round(ml.*10)/10),'HorizontalAlignment','center','VerticalAlignment','Bottom','FontSize',18,'FontWeight','bold');
