function [x,sigma]=decode(c,inputs)
x=angle(sum(c.*exp(i.*inputs.*pi/180))).*180/pi;
[a,x,sigma,nmse]=fitgauss_iterative(c,inputs,sum(c),x);
if sum(c)==0 || nmse>0.125
  x=NaN; sigma=NaN;
end



