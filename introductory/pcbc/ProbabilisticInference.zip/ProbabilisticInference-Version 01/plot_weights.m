function plot_weights()
%Test encoding and decoding of simple, monomodal, gaussian probability distributions
inputs=[-180:1:179];
centres=[-180:22.5:179];

%define weights, to produce a 1d basis function network, where nodes have gaussian RFs.
W=[];
for c=centres
  W=[W;code(c,inputs,15)];
end
W=bsxfun(@rdivide,W,max(1e-6,sum(W,2)));

figure(1),clf, plot(W','LineWidth',2)
set(gca,'XTick',[1:90:360],'XTickLabel',[-180:90:179],'FontSize',18);
axis([1,360,0,0.03])
set(gcf,'PaperSize',[10 8],'PaperPosition',[0 0.25 10 7.5],'PaperOrientation','Portrait');
print(gcf, '-dpdf', ['weigths_noprior.pdf']);

%define weights, to produce a 1d basis function network, where nodes have gaussian RFs. Strength of RFs is modulated by prior distribution. 
priorMean=0;
priorStd=60;
W=[];
for c=centres
  W=[W;code(c,inputs,15).*prior(inputs,priorMean,priorStd)];
end

figure(2), clf, plot(W','LineWidth',2)
set(gca,'XTick',[1:90:360],'XTickLabel',[-180:90:179],'FontSize',18);
axis([1,360,0,0.3])
set(gcf,'PaperSize',[10 8],'PaperPosition',[0 0.25 10 7.5],'PaperOrientation','Portrait');
print(gcf, '-dpdf', ['weigths_prior.pdf']);



function p=prior(x,Mean,Std)
p=0.2.*exp(-(0.5/Std^2).*(x-Mean).^2);


function c=code(x,X,sigma,noise)
c=zeros(1,length(X),'single');
c=19.*exp(-(0.5/sigma.^2).*min([abs(x-X);abs(x-(X+360));abs(x-(X-360))]).^2)./sigma;
if nargin>3 && noise
  c=single(imnoise(uint8(125.*c),'poisson'))./125; %add poisson noise
end
