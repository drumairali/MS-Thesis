function probability_2integrate_segregate()
%Perform optimal feature integration given two Gaussian probability distributions. Gradually change the degree of cue conflict to test when integration chnages to segregation.
stdInputs=20; %30;

stdWeights=15
centreStep=22.5
inputs=[-180:10:179];
centres=[-180:centreStep:179];
%define weights, to produce a 2d basis function network, where nodes have gaussian RFs.
W=[];
for c=centres
  W=[W;code(c,inputs,stdWeights),code(c,inputs,stdWeights)];
end
%normalise weights
W=bsxfun(@rdivide,W,max(1e-6,sum(W,2)));
[n,m]=size(W);

%define test cases
X=zeros(m,6);
k=0;
for m2=-10:10:60
  k=k+1;
  X(:,k)=[code(-30,inputs,stdInputs),code(m2,inputs,stdInputs)]'; 
end

%present test cases to network and record results
figure(size(X,2)+1),clf %figure for summary results
for k=1:size(X,2)
  x=X(:,k);
  [y,e,r]=dim_activation(W,x);
  figure(size(X,2)+1),axes('Position',[0.11*k,0.15,0.1,0.7]),
  rA=r(1:length(inputs));
  bar(rA,1,'FaceColor',[0,0.7,0]),axis([0.5,length(rA)+0.5,0,1.05])
  if k>1, set(gca,'YTick',[]); end
  set(gca,'XTick',[10:9:length(rA)],'XTickLabel',inputs(10:9:length(rA)));
  
  figure(k),clf
  plot_result2(x,r,y,inputs,centres);
  %print(gcf, '-dpdf', ['probability_2integrate_segregate',int2str(k),'.pdf']);
end
figure(size(X,2)+1)
set(gcf,'PaperSize',[20 4],'PaperPosition',[0 0.25 20 4],'PaperOrientation','Portrait');
print(gcf, '-dpdf', ['probability_2integrate_segregate_summary.pdf']);



function c=code(x,X,sigma,noise)
c=zeros(1,length(X),'single');
c=exp(-(0.5/sigma^2).*min([abs(x-X);abs(x-(X+360));abs(x-(X-360))]).^2);
if nargin>3 && noise
  c=single(imnoise(uint8(125.*c),'poisson'))./125; %add poisson noise
end
c=5.*c./sum(c);

