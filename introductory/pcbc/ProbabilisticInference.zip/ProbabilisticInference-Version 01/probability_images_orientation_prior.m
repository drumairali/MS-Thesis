function probability_images_orientation_prior()
%Apply PC/BC-DIM model of V1 to an image and plot prediction neuron responses and reconstructions

imSize=41;
angles=[0:11.25:179];
priorMean=90;
priorStd=45;
imageSigmaEquiv=12;

%define weights
disp('defining synaptic weights');
sigma=4;
wavel=1.5*sigma;
aspect=1./sqrt(2);
W=zeros(50000,2*imSize^2,'single');
D=zeros(50000,length(angles),'single');
k=0;
for i=1:2:imSize
  for j=1:2:imSize
    for phase=0:90:270
      for angletmp=angles
        k=k+1;
        angle=angletmp+5*randn; %jitter angle
        if rem(k,1000)==0; fprintf(1,'.%i.',k); end
        gabor=gabor2D(sigma,angle,aspect,wavel,phase,imSize,i-floor(imSize/2),j-floor(imSize/2));
        gabor=2.*single(gabor(:)'./sum(sum(abs(gabor))));
        gaborON=gabor; gaborON(gaborON<0)=0; 
        gaborOFF=-gabor; gaborOFF(gaborOFF<0)=0; 
        W(k,:)=[gaborON,gaborOFF];
        D(k,:)=0.05.*exp(-(0.5/5.^2)*min([abs(angles-angle);abs(angles-(angle-180));abs(angles-(angle+180))]).^2)'./5;
        D(k,:)=D(k,:).*prior(angles,priorMean,priorStd);
      end
    end
  end
end
disp(' ')
W=[W,D];
W=W(1:k,:);


%define test cases
surr=10;
imageOri=29;
I{1}=image_circular_grating(imSize-2*surr,surr,4,imageOri,0,1)-0.5;
X{1}=zeros(length(angles),1);
mu3=stats_gaussian_product(imageOri,imageSigmaEquiv,priorMean,priorStd)

imageOri=56.5;
I{2}=image_circular_grating(imSize-2*surr,surr,4,imageOri,0,1)-0.5;
X{2}=zeros(length(angles),1);
mu3=stats_gaussian_product(imageOri,imageSigmaEquiv,priorMean,priorStd)

imageOri=150;
I{3}=image_circular_grating(imSize-2*surr,surr,4,imageOri,0,1)-0.5;
X{3}=zeros(length(angles),1);
mu3=stats_gaussian_product(imageOri,imageSigmaEquiv,priorMean,priorStd)


%present test cases to network and record results
for k=1:length(I)
  Ion=I{k}(:); Ion(Ion<0)=0;
  Ioff=-I{k}(:); Ioff(Ioff<0)=0;
  x=[Ion;Ioff;X{k}]; 
  [y,e,r]=dim_activation(W,x);

  figure(k),clf
  plot_result_images(x,r,y,imSize,angles,W);
  print(gcf, '-dpdf', ['probability_images_orientation_prior',int2str(k),'.pdf']);
end


%test accuracy of integration across many random trials
numTests=100
decode_compare=zeros(numTests,3);
for k=1:numTests
  fprintf(1,'.%i.',k); 
  
  %randomly select parameters of input
  mu1=30+120*rand; 
  sigma1=imageSigmaEquiv;
 
  %calc bayesian estimate of posterior
  [mu3,sigma3]=stats_gaussian_product(mu1,sigma1,priorMean,priorStd);    

  %calc network estimate of posterior
  Itmp=image_circular_grating(imSize-2*surr,surr,4,mu1,0,1)-0.5;
  Ion=Itmp(:); Ion(Ion<0)=0;
  Ioff=-Itmp(:); Ioff(Ioff<0)=0;
  x=[Ion;Ioff;X{1}]; 

  [y,e,r]=dim_activation(W,x);
    
  [mu3est]=decode(r(1+2*imSize.^2:end).^2,angles');
 
  %store estimates for plotting later
  decode_compare(k,:)=[mu3,sigma3.^2,mu3est];
end
disp(' ')

figure(length(I)+1),clf
plot(decode_compare(:,1),decode_compare(:,3),'o','MarkerFaceColor','b','MarkerSize',6);
hold on
plot([10,170],[10,170],'k--','LineWidth',2)
set(gca,'YTick',[0:45:179],'XTick',[0:45:179],'FontSize',15)
axis('equal','tight')
xlabel('Optimal Estimate of Mean  ');
ylabel('Network Estimate of Mean  ')
set(gcf,'PaperSize',[10 8],'PaperPosition',[0 0.25 10 7.5],'PaperOrientation','Portrait');
print(gcf, '-dpdf', ['probability_images_orientation_prior_mean_accuracy.pdf']);




function [x]=decode(c,inputs)
x=angle(sum(c.*exp(i.*inputs.*pi/180))).*180/pi;
if sum(c)==0, x=NaN; end




function p=prior(x,Mean,Std)
p=80.*exp(-(0.5/Std^2).*min([abs(x-Mean);abs(x-(Mean-180));abs(x-(Mean+180))]).^2)./Std;
