function probability_3basis()
%calculate fn(a,b), where a and b are real numbers (in a limited range) and fn is +
Ainputs=[-60:5:60];
Binputs=[-60:5:60];
Cinputs=[min(Ainputs)+min(Binputs):10:max(Ainputs)+max(Binputs)];
Acentres=[-60:10:60];
Bcentres=[-60:10:60];

%define weights, to produce a 2d basis function network, where nodes have gaussian RFs.
W=[];
for a=Acentres
  for b=Bcentres
    c=a+b;
    W=[W;code(a,Ainputs,10,0,1),code(b,Binputs,10,0,1),code(c,Cinputs,10,0,1)];
  end
end
%normalise weights
W=bsxfun(@rdivide,W,max(1e-6,sum(W,2)));
[n,m]=size(W);

%define test cases
X=zeros(m,4);
null=zeros(1,length(Cinputs));
%function approximation:
X(:,1)=[code(-30,Ainputs,10),code(20,Binputs,10),null]'; %-30+20=?
X(:,2)=[code(-30,Ainputs,10),zeros(1,length(Binputs)),code(-10,Cinputs,10)]'; %-30+?=-10?
%feature integration:
X(:,3)=[code(-30,Ainputs,10),code(20,Binputs,10),code(10,Cinputs,10)]'; %-30+20=10!
X(:,4)=[code(-30,Ainputs,10),code(20,Binputs,10),code(10,Cinputs,20)]'; %-30+20=10!

%present test cases to network and record results
for k=1:size(X,2)
  x=X(:,k);
  [y,e,r]=dim_activation(W,x);
  figure(k),clf
  plot_result3(x,r,y,Ainputs,Binputs,Cinputs);
  print(gcf, '-dpdf', ['probability_3basis',int2str(k),'.pdf']);
end


%test for gain modulation
x=[code(-30,Ainputs,10),code(-30,Binputs,10),null]';
[y,e,r]=dim_activation(W,x);
[val,ind]=max(y);%choose node to record from
k=0;
for b=-30:7.5:0
  k=k+1;
  p=0;
  for a=Ainputs
    p=p+1;
    x=[code(a,Ainputs,10),code(b,Binputs,10),null]';
    [y,e,r,ytrace]=dim_activation(W,x);
    resp(k,p)=mean(ytrace(ind,:));
  end
end
figure(size(X,2)+1),clf
plot(resp','LineWidth',3)
legend([num2str([-30:7.5:0]', 'B=% 3.1f'),[' .';'  ';'  ';'  ';'  ']]);
axis([1,length(Ainputs),0,0.5])
set(gca,'XTick',[1:6:length(Ainputs)],'XTickLabel',Ainputs(1:6:length(Ainputs)),'FontSize',15);
xlabel('A');ylabel('response')
set(gcf,'PaperSize',[10 8],'PaperPosition',[0 0.25 10 7.5],'PaperOrientation','Portrait');

print(gcf, '-dpdf', ['probability_3basis_gainmod.pdf']);


%calculate accuracy of function approximation averaged over many trials
trials=1e6
%test accuracy of calculating c=a+b using noisy population codes
range=45
decode_compare=zeros(trials,3);
for k=1:trials
  if rem(k,1000)==0; fprintf(1,'.%i.',k); end
  a=(2*range)*rand-range;
  b=(2*range)*rand-range;
  x=[code(a,Ainputs,10,1),code(b,Binputs,10,1),null]';
  aML=decode(x(1:length(Ainputs))',Ainputs);
  bML=decode(x(length(Ainputs)+[1:length(Binputs)])',Binputs);

  [y,e,r]=dim_activation(W,x);
  
  rNet=decode(r(1+length(Ainputs)+length(Binputs):end)',Cinputs);
  
  decode_compare(k,:)=[a+b,aML+bML,rNet];
end
disp(' ');
varML=est_var(decode_compare(:,1)',decode_compare(:,2)') %compare function estimated from input pattern to true value
varNet=est_var(decode_compare(:,1)',decode_compare(:,3)') %compare function estimated from reconstruction to true value
100.*(varNet-varML)./varML

%test accuracy of calculating b=c-a using noisy population codes
range=range/2;
decode_compare=zeros(trials,3);
for k=1:trials
  if rem(k,1000)==0; fprintf(1,'.%i.',k); end
  a=(2*range)*rand-range;
  c=(2*range)*rand-range;
  x=[code(a,Ainputs,10,1),zeros(1,length(Binputs)),code(c,Cinputs,10,1)]';
  aML=decode(x(1:length(Ainputs))',Ainputs);
  cML=decode(x(1+length(Ainputs)+length(Binputs):end)',Cinputs);

  [y,e,r]=dim_activation(W,x);
  
  rNet=decode(r(length(Ainputs)+[1:length(Binputs)])',Binputs);
  
  decode_compare(k,:)=[c-a,cML-aML,rNet];
end
disp(' ');
varML=est_var(decode_compare(:,1)',decode_compare(:,2)') %compare function estimated from input pattern to true value
varNet=est_var(decode_compare(:,1)',decode_compare(:,3)') %compare function estimated from reconstruction to true value
100.*(varNet-varML)./varML



function v=decode(x,inputs)
v=sum(x.*inputs)./sum(x); 
if sum(x)==0, v=NaN; end



function var=est_var(true,est)
M=length(true);
var=sum((est-true).^2)/(M-1);

