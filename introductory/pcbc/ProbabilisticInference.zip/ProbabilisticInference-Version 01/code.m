function c=code(x,X,sigma,noise,norm)
c=zeros(1,length(X),'single');
if length(X)==2
  c(x==X)=1;
else
  c=10.*exp(-(0.5/sigma.^2).*(x-X).^2)./sigma;
end
if nargin>3 && noise
  c=single(imnoise(uint8(125.*c),'poisson'))./125; %add poisson noise
end
if nargin>4 && norm
  c=c./sum(c);
end

