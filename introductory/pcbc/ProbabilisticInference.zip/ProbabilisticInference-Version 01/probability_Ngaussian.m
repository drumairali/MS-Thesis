function probability_Ngaussian()
%Test encoding and decoding of simple, multimodal, gaussian probability distributions
inputs=[-180:10:179];
centres=[-180:22.5:179];

%define weights, to produce a 1d basis function network, where nodes have gaussian RFs.
W=[];
for c=centres
  W=[W;code(c,inputs,15)];
end

%normalise weights
W=bsxfun(@rdivide,W,max(1e-6,sum(W,2)));
[n,m]=size(W);

%define test cases
X=zeros(m,2);
X(:,1)=code(0,inputs,20,1)'+code(105,inputs,25,1)'+code(-85,inputs,15,1)'; %tri-modal, noisy
X(:,2)=code(0,inputs,20)'+code(105,inputs,25)'+code(-85,inputs,15)'; %tri-modal, no noise

for k=1:size(X,2)
  x=X(:,k);
  [y,e,r]=dim_activation(W,x);
  figure(k),clf
  plot_result(x,r,y,inputs,centres);
  print(gcf, '-dpdf', ['probability_Ngaussian',int2str(k),'.pdf']);
end



function c=code(x,X,sigma,noise)
c=zeros(1,length(X),'single');
c=18.*exp(-(0.5/sigma.^2).*min([abs(x-X);abs(x-(X+360));abs(x-(X-360))]).^2)./sigma;;
if nargin>3 && noise
  c=single(imnoise(uint8(125.*c),'poisson'))./125; %add poisson noise
end



function plot_result(x,r,y,inputs,centres)
top=1.2;
axes('Position',[0.12,0.05,0.76,0.24]),
bar(x,1,'k'),axis([0.5,length(x)+0.5,0,top])
set(gca,'XTick',[1:9:length(x)],'XTickLabel',inputs(1:9:length(x)),'FontSize',18);
text(0.01,1,'x','Units','normalized','color','k','FontSize',18,'FontWeight','bold','VerticalAlignment','top')

axes('Position',[0.12,0.38,0.76,0.24]),
bar(y,1,'r'),axis([0.5,length(y)+0.5,0,top])
set(gca,'XTick',[1:2:length(y)],'XTickLabel',[1:2:length(y)],'FontSize',18);
text(0.01,1,'y','Units','normalized','color','r','FontSize',18,'FontWeight','bold','VerticalAlignment','top')

axes('Position',[0.12,0.71,0.76,0.24]),
bar(r,1,'FaceColor',[0,0.7,0]),axis([0.5,length(x)+0.5,0,top])
set(gca,'XTick',[1:9:length(x)],'XTickLabel',inputs(1:9:length(x)),'FontSize',18);
text(0.01,1,'r','Units','normalized','color',[0,0.7,0],'FontSize',18,'FontWeight','bold','VerticalAlignment','top')


set(gcf,'PaperSize',[18 16],'PaperPosition',[0 0.5 18 15],'PaperOrientation','Portrait');
