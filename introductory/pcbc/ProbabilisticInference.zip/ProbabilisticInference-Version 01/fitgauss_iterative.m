function [a,x,sigma,nmse]=fitgauss_iterative(c,inputs,a,mu)
x=NaN;sigma=NaN;nmse=Inf;
for sigmaIt=10:5:60
 [aIt,xIt,sigmaIt,nmseIt]=fitgauss(c,inputs,a,mu,sigmaIt);
 if nmseIt<nmse
   x=xIt;sigma=sigmaIt;nmse=nmseIt;
 end
end
sigma=abs(sigma);