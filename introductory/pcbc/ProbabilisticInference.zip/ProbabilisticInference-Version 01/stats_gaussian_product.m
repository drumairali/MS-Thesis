function [mu3,sigma3]=stats_gaussian_product(mu1,sigma1,mu2,sigma2)
%calc the mean and variance of the Gaussian distribution that results from multiplying two other Gaussian distributions

mu3=(mu1*sigma2^2+mu2*sigma1^2)/(sigma1^2+sigma2^2);
var3=(sigma1^2*sigma2^2)/(sigma1^2+sigma2^2);
sigma3=sqrt(var3);