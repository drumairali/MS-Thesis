function [y,e,r,x,ytrace]=dim_activation_hierarchical(W,x,interconnects,y,iterations)
epsilon1=1e-6;
epsilon2=1e-3;
if nargin<5 || isempty(iterations), iterations=25; end
if nargin<4 || isempty(y), initY=1; else, initY=0; end

numStages=length(W);
for s=1:numStages
  [n{s},m{s}]=size(W{s});
  if initY
    y{s}=zeros(n{s},1,'single'); %initialise prediction neuron outputs
  end
  %set feedback weights equal to feedforward weights normalized by maximum value:
  V{s}=bsxfun(@rdivide,abs(W{s}),max(1e-6,max(abs(W{s}),[],2)));
  V{s}=V{s}'; %avoid having to take transpose at each iteration
end

for t=1:iterations  
  for s=1:numStages
    %update responses

    if s+1<=numStages && t>1
      %provide top-down input from subsequent processing stage by copying part of the subsequent stage's reconstruction to form part of the input to this stage
      x{s}(interconnects{s,s+1})=r{s+1}(interconnects{s+1,s});
    end
    r{s}=V{s}*y{s};  
    e{s}=x{s}./max(epsilon2,r{s});
    y{s}=max(epsilon1,y{s}).*(W{s}*e{s});

    if s+1<=numStages
      %provide feedforward input to subsequent processing stage by copying part of this stage's reconstruction to form part of the input to the subsequent stage
      x{s+1}(interconnects{s+1,s})=r{s}(interconnects{s,s+1});
    end
    if nargout>3, ytrace{s}(:,t)=y{s}; end
  end
end	
