function probability_2integrate()
%perform optimal feature integration given two Gaussian probability distributions
inputs=[-180:10:179];
centres=[-180:22.5:179];

%define weights, to produce a 2d basis function network, where nodes have gaussian RFs.
W=[];
for c=centres
  W=[W;code(c,inputs,15),code(c,inputs,15)];
end
%normalise weights
W=bsxfun(@rdivide,W,max(1e-6,sum(W,2)));
[n,m]=size(W);

%define test cases
X=zeros(m,4);
X(:,1)=[code(-30,inputs,20),code(-10,inputs,20)]'; 
X(:,2)=[code(-30,inputs,40),code(-10,inputs,20)]'; 
X(:,3)=[code(-30,inputs,20),code(60,inputs,20)]'; 
X(:,4)=[code(-30,inputs,20)+code(50,inputs,20),code(60,inputs,20)]'; 

%present test cases to network and record results
for k=1:size(X,2)
  x=X(:,k);
  [y,e,r]=dim_activation(W,x);
  figure(k),clf
  plot_result2(x,r,y,inputs,centres);
  print(gcf, '-dpdf', ['probability_2integrate',int2str(k),'.pdf']);
end


%test accuracy of integration across many random trials
numTrials=1008
numTests=100
for k=1:numTests
  fprintf(1,'.%i.',k); 
  %randomly select parameters of input
  mu1=0; %360*rand-180;
  mu2=mu1+(20*rand-10);
  sigma1=20+40*rand;
  sigma2=20+40*rand;

  %for these parameters average estimates over many trials
  for trial=1:numTrials
    %batch together all trials fo faster execution of dim
    x(:,trial)=[code(mu1,inputs,sigma1,1),code(mu2,inputs,sigma2,1)]';
  end
  [y,e,r]=dim_activation(W,x);
  mu3Mean=[];
  sigma3Mean=[];
  mu3estMean=[];
  sigma3estMean=[];
  for trial=1:numTrials
    %analyse results from each trial
    [mu1act,sigma1act]=decode(x(1:length(inputs),trial)',inputs);
    [mu2act,sigma2act]=decode(x(1+length(inputs):end,trial)',inputs);
    
    [mu3Mean(trial),sigma3Mean(trial)]=stats_gaussian_product(mu1act,sigma1act,mu2act,sigma2act);
    [mu3estMean(trial),sigma3estMean(trial)]=decode(r(1:length(inputs),trial)'.^2,inputs);
  end
  %take average results across trials
  decode_compare(k,:)=[nanmean(mu3Mean),nanmean(sigma3Mean.^2),nanmean(mu3estMean),nanmean(sigma3estMean.^2)];
end
disp(' ')

figure(size(X,2)+1),clf
plot(decode_compare(:,1),decode_compare(:,3),'o','MarkerFaceColor','b','MarkerSize',6);
hold on
plot([-10,10],[-10,10],'k--','LineWidth',2)
set(gca,'YTick',[-8:8:8],'XTick',[-8:8:8],'FontSize',15)
axis('equal','tight')
xlabel('Optimal Estimate of Mean  ');
ylabel('Network Estimate of Mean  ')
set(gcf,'PaperSize',[10 8],'PaperPosition',[0 0.25 10 7.5],'PaperOrientation','Portrait');
print(gcf, '-dpdf', ['probability_2integrate_mean_accuracy.pdf']);

figure(size(X,2)+2),clf
plot(decode_compare(:,2),decode_compare(:,4),'o','MarkerFaceColor','b','MarkerSize',6);
hold on
plot([100,2000],[100,2000],'k--','LineWidth',2)
set(gca,'YTick',[500:500:1500],'YTickLabel',' ','XTick',[500:500:1500],'FontSize',15)
text([100,100,100]-10,[500:500:1500],int2str([500:500:1500]'),'Rotation',90,'VerticalAlignment','bottom','HorizontalAlignment','center','FontSize',15)
axis('equal','tight')
xlabel('Optimal Estimate of \sigma^2  ');
ylabel({'Network Estimate of \sigma^2  ';'  '});
set(gcf,'PaperSize',[10 8],'PaperPosition',[0 0.25 10 7.5],'PaperOrientation','Portrait');
print(gcf, '-dpdf', ['probability_2integrate_var_accuracy.pdf']);



function c=code(x,X,sigma,noise)
c=zeros(1,length(X),'single');
c=exp(-(0.5/sigma^2).*min([abs(x-X);abs(x-(X+360));abs(x-(X-360))]).^2);
if nargin>3 && noise
  c=single(imnoise(uint8(125.*c),'poisson'))./125; %add poisson noise
end
c=5.*c./sum(c);



