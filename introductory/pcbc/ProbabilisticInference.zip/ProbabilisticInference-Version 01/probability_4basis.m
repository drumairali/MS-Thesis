function probability_4basis()
%calculate fn(a,b,c), where a, b and c are real numbers (in a limited range) and fn is +
Ainputs=[-60:5:60];
Binputs=[-60:5:60];
Cinputs=[-60:5:60];
Dinputs=[min(Ainputs)+min(Binputs)+min(Cinputs):10:max(Ainputs)+max(Binputs)+max(Cinputs)];
Acentres=[-60:10:60];
Bcentres=[-60:10:60];
Ccentres=[-60:10:60];

%define weights, to produce a 3d basis function network, where nodes have gaussian RFs.
W=[];
for a=Acentres
  for b=Bcentres
    for c=Ccentres
      d=a+b+c;
      W=[W;code(a,Ainputs,10,0,1),code(b,Binputs,10,0,1),code(c,Cinputs,10,0,1),code(d,Dinputs,10,0,1)];
    end
  end
end
%normalise weights
W=bsxfun(@rdivide,W,max(1e-6,sum(W,2)));
[n,m]=size(W);
n

%define test cases
X=zeros(m,4);
null=zeros(1,length(Dinputs));
%function approximation:
X(:,1)=[code(-30,Ainputs,10),code(20,Binputs,10),code(20,Cinputs,10),null]'; %-30+20+20=?
X(:,2)=[code(-30,Ainputs,10),zeros(1,length(Binputs)),code(20,Cinputs,10),code(10,Dinputs,10)]'; %-30+?+20=10?
X(:,3)=[code(30,Ainputs,10)+code(-30,Ainputs,10),code(20,Binputs,10),code(20,Cinputs,10),null]'; %(30 &-30)+20+20=?
X(:,4)=[code(-30,Ainputs,10),zeros(1,length(Binputs)),code(20,Cinputs,10),null]'; %-30+20+20=?

for k=1:size(X,2)
  x=X(:,k);
  [y,e,r]=dim_activation(W,x);
  %[y,e,r]=sub_activation(W,x);
  figure(k),clf
  plot_result(x,r,y,Ainputs,Binputs,Cinputs,Dinputs);
  print(gcf, '-dpdf', ['probability_4basis',int2str(k),'.pdf']);
end



function plot_result(x,r,y,Ainputs,Binputs,Cinputs,Dinputs)
xA=x(1:length(Ainputs));
xB=x(length(Ainputs)+[1:length(Binputs)]);
xC=x(length(Ainputs)+length(Binputs)+[1:length(Cinputs)]);
xD=x(length(Ainputs)+length(Binputs)+length(Cinputs)+[1:length(Dinputs)]);
rA=r(1:length(Ainputs));
rB=r(length(Ainputs)+[1:length(Binputs)]);
rC=r(length(Ainputs)+length(Binputs)+[1:length(Cinputs)]);
rD=r(length(Ainputs)+length(Binputs)+length(Cinputs)+[1:length(Dinputs)]);
top=1.05;

axes('Position',[0.12,0.05,0.18,0.24]),
bar(xA,1,'k'),axis([0.5,length(xA)+0.5,0,top])
set(gca,'XTick',[4:9:length(xA)-3],'XTickLabel',Ainputs(4:9:length(xA)-3),'FontSize',18);
plot_decode(xA,Ainputs);
text(0.04,1,'x_a','Units','normalized','color','k','FontSize',18,'FontWeight','bold','VerticalAlignment','top')

axes('Position',[0.3133,0.05,0.18,0.24]),
bar(xB,1,'k'),axis([0.5,length(xB)+0.5,0,top])
set(gca,'YTick',[],'XTick',[4:9:length(xB)-3],'XTickLabel',Binputs(4:9:length(xB)-3),'FontSize',18);
plot_decode(xB,Binputs);
text(0.04,1,'x_b','Units','normalized','color','k','FontSize',18,'FontWeight','bold','VerticalAlignment','top')

axes('Position',[0.5066,0.05,0.18,0.24]),
bar(xC,1,'k'),axis([0.5,length(xC)+0.5,0,top])
set(gca,'YTick',[],'XTick',[4:9:length(xC)-3],'XTickLabel',Cinputs(4:9:length(xC)-3),'FontSize',18);
plot_decode(xC,Cinputs);
text(0.04,1,'x_c','Units','normalized','color','k','FontSize',18,'FontWeight','bold','VerticalAlignment','top')

axes('Position',[0.70,0.05,0.18,0.24]),
bar(xD,1,'k'),axis([0.5,length(xD)+0.5,0,top])
set(gca,'YTick',[],'XTick',[7:12:length(xD)-6],'XTickLabel',Dinputs(7:12:length(xD)-6),'FontSize',18);
plot_decode(xD,Dinputs);
text(0.04,1,'x_d','Units','normalized','color','k','FontSize',18,'FontWeight','bold','VerticalAlignment','top')

axes('Position',[0.12,0.38,0.76,0.24]),
bar(y,1,'r'),axis([0.5,length(y)+0.5,0,top])
set(gca,'FontSize',18);
text(0.01,1,'y','Units','normalized','color','r','FontSize',18,'FontWeight','bold','VerticalAlignment','top')

axes('Position',[0.12,0.71,0.18,0.24]),
bar(rA,1,'FaceColor',[0,0.7,0]),axis([0.5,length(rA)+0.5,0,top])
set(gca,'XTick',[4:9:length(xA)-3],'XTickLabel',Ainputs(4:9:length(xA)-3),'FontSize',18);
plot_decode(rA,Ainputs);
text(0.04,1,'r_a','Units','normalized','color',[0,0.7,0],'FontSize',18,'FontWeight','bold','VerticalAlignment','top')

axes('Position',[0.3133,0.71,0.18,0.24]),
bar(rB,1,'FaceColor',[0,0.7,0]),axis([0.5,length(rB)+0.5,0,top])
set(gca,'YTick',[],'XTick',[4:9:length(xB)-3],'XTickLabel',Binputs(4:9:length(xB)-3),'FontSize',18);
plot_decode(rB,Binputs);
text(0.04,1,'r_b','Units','normalized','color',[0,0.7,0],'FontSize',18,'FontWeight','bold','VerticalAlignment','top')

axes('Position',[0.5066,0.71,0.18,0.24]),
bar(rC,1,'FaceColor',[0,0.7,0]),axis([0.5,length(rC)+0.5,0,top])
set(gca,'YTick',[],'XTick',[4:9:length(xC)-3],'XTickLabel',Cinputs(4:9:length(xC)-3),'FontSize',18);
plot_decode(rC,Cinputs);
text(0.04,1,'r_c','Units','normalized','color',[0,0.7,0],'FontSize',18,'FontWeight','bold','VerticalAlignment','top')

axes('Position',[0.70,0.71,0.18,0.24]),
bar(rD,1,'FaceColor',[0,0.7,0]),axis([0.5,length(rD)+0.5,0,top])
set(gca,'YTick',[],'XTick',[7:12:length(xD)-6],'XTickLabel',Dinputs(7:12:length(xD)-6),'FontSize',18);
plot_decode(rD,Dinputs);
text(0.04,1,'r_d','Units','normalized','color',[0,0.7,0],'FontSize',18,'FontWeight','bold','VerticalAlignment','top')

set(gcf,'PaperSize',[18 16],'PaperPosition',[0 0.5 18 15],'PaperOrientation','Portrait');


