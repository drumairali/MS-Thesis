function plot_decode(x,inputs)
hold on, 
%ml=sum(x'.*inputs)./sum(x); 
[ml,sigma]=decode(x',inputs);
mlconv=1+((ml-min(inputs)).*(length(inputs)-1)./(max(inputs)-min(inputs)));
plot(mlconv.*[1,1],[0,100],'w--','LineWidth',2),
plot(mlconv.*[1,1],[0,100],'k--'),
ax=axis;
text('Position',[mlconv,ax(4)*0.98],'String',num2str(round(ml.*10)/10),'HorizontalAlignment','center','VerticalAlignment','Bottom','FontSize',18,'FontWeight','bold');
